Repcached patch to add replication feature to Memcached

Fork from ignacykasperowicz git repository https://github.com/ignacykasperowicz/repcached/blob/master/repcached-2.3.1-1.4.13.patch
